const CONSTANTS = {
    MODULE_NAME: "forien-unidentified-items",
    PATH: `modules/forien-unidentified-items/`,
    DEFAULT_ICON: "unidentified.png"
};
CONSTANTS.PATH = `modules/${CONSTANTS.MODULE_NAME}/`;
export default CONSTANTS;
