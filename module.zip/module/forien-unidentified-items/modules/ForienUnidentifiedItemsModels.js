export class MystifiedData {
}
export var MystifiedFlags;
(function (MystifiedFlags) {
    MystifiedFlags["ORIG_DATA"] = "origData";
})(MystifiedFlags || (MystifiedFlags = {}));
