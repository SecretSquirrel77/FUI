export default {
    DEFAULT_PROPERTIES: {}
};
