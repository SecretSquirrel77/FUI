import API from "./api.js";
import { MystifiedFlags } from "./ForienUnidentifiedItemsModels.js";
export default function registerItemClassMethod() {
    //@ts-ignore
    CONFIG.Item.documentClass.prototype.isMystified = function isMystified() {
        return API.isMystified(this);
    };
    Object.defineProperty(CONFIG.Item.documentClass.prototype, MystifiedFlags.ORIG_DATA, {
        get: function origData() {
            return API.getOrigData(this);
        }
    });
}
